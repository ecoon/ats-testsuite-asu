This folder contains the following files:

File Name: princeton_k34_-2.625_-60.125.dat: 
Info: forcing from Princeton dataset except precipitation from K34 flux tower 


File Name: metadata_princeton_trmm.txt 
Info: metadata for the princeton_k34_-2.625_-60.125.dat file, including names of variable, units, data source, available time periods 


File Name: princeton_trmm_-2.625_-60.125.dat
Info: forcing from Princeton dataset except precipitation from TRMM


File Name: metadata_princeton_k34.txt 
Info: metadata for the princeton_trmm_-2.625_-60.125.dat file, including names of variable, units, data source, available time periods
